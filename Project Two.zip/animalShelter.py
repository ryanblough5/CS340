from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33553
        DB = 'AAC'
        COL = 'animals'
        #
        # Intialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
# Complete this create method to implement C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)   # data should be dictionary
        else:
            raise Exception("Nothing to save, because the data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, data):
        if data is not None:
            return self.database.animals.find(data)   # data should be dictionary
        else:
            raise Exception("Nothing to save, because data paramter is empty")